"""Built-in ModelBake adapters."""

