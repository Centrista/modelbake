"""ModelBake test suite."""

